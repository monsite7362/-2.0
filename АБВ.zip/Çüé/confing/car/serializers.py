from rest_framework import serializers
from django.contrib.auth.password_validation import validate_password
from .models import CustomUser, Brand, Dealer, Car, MaintenanceRecord
from .masking import DataMasker


class MaskedModelSerializer(serializers.ModelSerializer):
    """Базовый сериализатор с поддержкой маскировки"""
    
    def __init__(self, *args, **kwargs):
        self.mask_data = kwargs.pop('mask_data', False)
        self.unmask_data = kwargs.pop('unmask_data', False)
        super().__init__(*args, **kwargs)
    
    def to_representation(self, instance):
        data = super().to_representation(instance)
        
        if self.mask_data:
            if hasattr(self.Meta.model, '__name__'):
                model_name = self.Meta.model.__name__.lower()
                if model_name == 'customuser':
                    data = DataMasker.mask_user_data(data, original_id=data.get('id'))
                elif model_name == 'car':
                    data = DataMasker.mask_car_data(data, original_id=data.get('id'))
                elif model_name == 'brand':
                    data = DataMasker.mask_brand_data(data, original_id=data.get('id'))
        
        elif self.unmask_data:
            if data.get('is_masked'):
                if 'user_masked' in str(data.get('id', '')):
                    data = DataMasker.unmask_user_data(data)
                elif 'car_masked' in str(data.get('id', '')):
                    data = DataMasker.unmask_car_data(data)
                elif 'brand_masked' in str(data.get('id', '')):
                    data = DataMasker.unmask_brand_data(data)
        
        return data


class MaskedUserSerializer(MaskedModelSerializer):
    """Сериализатор пользователя с маскировкой"""
    full_name = serializers.SerializerMethodField()
    user_type_display = serializers.CharField(source='get_user_type_display', read_only=True)
    dealer_name = serializers.CharField(source='dealer.name', read_only=True)
    
    class Meta:
        model = CustomUser
        fields = [
            'id', 'username', 'email', 'first_name', 'last_name', 'full_name',
            'user_type', 'user_type_display', 'phone', 'birth_date', 'address',
            'photo', 'hire_date', 'is_verified', 'receive_notifications',
            'dealer', 'dealer_name', 'is_active', 'date_joined', 'last_login',
            'is_masked', 'original_id'
        ]
        read_only_fields = ['date_joined', 'last_login', 'is_masked', 'original_id']
        extra_kwargs = {
            'password': {'write_only': True},
        }
    
    def get_full_name(self, obj):
        return obj.get_full_name()
    
    def create(self, validated_data):
        mask_on_create = validated_data.pop('mask_on_create', False)
        
        if mask_on_create:
            validated_data = DataMasker.mask_user_data(validated_data)
        
        user = CustomUser.objects.create_user(
            username=validated_data['username'],
            email=validated_data.get('email', ''),
            password=validated_data['password'],
            first_name=validated_data.get('first_name', ''),
            last_name=validated_data.get('last_name', ''),
            user_type=validated_data.get('user_type', 'client')
        )
        return user


# ... остальные сериализаторы (MaskedCarSerializer, MaskedBrandSerializer и т.д.) ...
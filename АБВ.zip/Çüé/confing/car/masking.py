import random
import string
from datetime import datetime
from faker import Faker

fake = Faker('ru_RU')


class DataMasker:
    """Класс для двухсторонней маскировки данных"""
    
    _mask_maps = {
        'users': {},
        'cars': {},
        'brands': {},
        'dealers': {},
        'maintenance': {}
    }
    
    # ... остальной код из предыдущего ответа (без импортов serializers) ...
    
    @staticmethod
    def generate_masked_vin():
        """Генерация замаскированного VIN"""
        letters = ''.join(random.choices(string.ascii_uppercase, k=3))
        numbers = ''.join(random.choices(string.digits, k=10))
        letters2 = ''.join(random.choices(string.ascii_uppercase, k=4))
        return f"{letters}{numbers}{letters2}"
    
    @staticmethod
    def generate_masked_license_plate():
        """Генерация замаскированного госномера"""
        regions = ['А','В','Е','К','М','Н','О','Р','С','Т','У','Х']
        return (f"{random.choice(regions)}"
                f"{random.randint(0,9)}{random.randint(0,9)}{random.randint(0,9)}"
                f"{random.choice(regions)}"
                f"{random.choice(regions)}"
                f"{random.randint(0,9)}{random.randint(0,9)}")
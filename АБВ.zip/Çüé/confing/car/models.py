from django.db import models
from django.contrib.auth.models import AbstractUser
from django.core.validators import MinValueValidator, MaxValueValidator

class CustomUser(AbstractUser):
    """Кастомная модель пользователя"""
    USER_TYPES = [
        ('admin', 'Администратор'),
        ('manager', 'Менеджер'),
        ('client', 'Клиент'),
        ('mechanic', 'Механик'),
        ('driver', 'Водитель'),
    ]
    
    user_type = models.CharField(
        max_length=20,
        choices=USER_TYPES,
        default='client',
        verbose_name="тип пользователя"
    )
    phone = models.CharField(
        max_length=20,
        blank=True,
        null=True,
        verbose_name="телефон"
    )
    birth_date = models.DateField(
        blank=True,
        null=True,
        verbose_name="дата рождения"
    )
    address = models.CharField(
        max_length=255,
        blank=True,
        null=True,
        verbose_name="адрес"
    )
    photo = models.ImageField(
        upload_to='users/photos/',
        blank=True,
        null=True,
        verbose_name="фотография"
    )
    hire_date = models.DateField(
        blank=True,
        null=True,
        verbose_name="дата приема на работу"
    )
    notes = models.TextField(
        blank=True,
        null=True,
        verbose_name="примечания"
    )
    is_verified = models.BooleanField(
        default=False,
        verbose_name="верифицирован"
    )
    receive_notifications = models.BooleanField(
        default=True,
        verbose_name="получать уведомления"
    )
    
    class Meta:
        verbose_name = "пользователь"
        verbose_name_plural = "пользователи"
        ordering = ['last_name', 'first_name']
    
    def __str__(self):
        return f"{self.get_full_name()} ({self.get_user_type_display()})"
    
    def get_full_name(self):
        if self.first_name and self.last_name:
            return f"{self.last_name} {self.first_name}"
        return self.username


class Brand(models.Model):
    """Производитель автомобилей"""
    name = models.CharField(max_length=50, unique=True, verbose_name="название")
    country = models.CharField(max_length=50, verbose_name="страна")
    foundation_year = models.PositiveIntegerField(verbose_name="год основания")
    logo = models.ImageField(upload_to='brands/logos/', blank=True, null=True, verbose_name="логотип")
    headquarters = models.CharField(max_length=200, verbose_name="штаб-квартира")
    ceo = models.CharField(max_length=100, verbose_name="генеральный директор")
    annual_revenue = models.DecimalField(
        max_digits=15,
        decimal_places=2,
        blank=True,
        null=True,
        verbose_name="годовой доход (млрд $)"
    )
    employees_count = models.PositiveIntegerField(
        blank=True,
        null=True,
        verbose_name="количество сотрудников"
    )
    description = models.TextField(blank=True, null=True, verbose_name="описание")
    website = models.URLField(blank=True, null=True, verbose_name="веб-сайт")
    is_active = models.BooleanField(default=True, verbose_name="активный")
    
    class Meta:
        verbose_name = "производитель"
        verbose_name_plural = "производители"
        ordering = ['name']
    
    def __str__(self):
        return self.name


class Dealer(models.Model):
    """Дилерский центр"""
    name = models.CharField(max_length=100, verbose_name="название")
    address = models.CharField(max_length=255, verbose_name="адрес")
    phone = models.CharField(max_length=20, verbose_name="телефон")
    email = models.EmailField(verbose_name="email")
    website = models.URLField(blank=True, null=True, verbose_name="веб-сайт")
    is_official = models.BooleanField(default=True, verbose_name="официальный дилер")
    brand = models.ForeignKey(Brand, on_delete=models.CASCADE, related_name='dealers', verbose_name="бренд")
    opening_year = models.PositiveIntegerField(verbose_name="год открытия")
    square_meters = models.PositiveIntegerField(verbose_name="площадь (м²)")
    service_capacity = models.PositiveIntegerField(verbose_name="вместимость сервиса")
    rating = models.DecimalField(
        max_digits=3,
        decimal_places=2,
        validators=[MinValueValidator(0), MaxValueValidator(5)],
        blank=True,
        null=True,
        verbose_name="рейтинг"
    )
    is_active = models.BooleanField(default=True, verbose_name="активный")
    
    class Meta:
        verbose_name = "дилерский центр"
        verbose_name_plural = "дилерские центры"
    
    def __str__(self):
        return f"{self.name} ({self.brand.name})"


class Car(models.Model):
    """Автомобиль"""
    VEHICLE_TYPES = [
        ('sedan', 'Седан'),
        ('suv', 'Внедорожник'),
        ('hatchback', 'Хэтчбек'),
        ('coupe', 'Купе'),
        ('convertible', 'Кабриолет'),
        ('minivan', 'Минивэн'),
        ('truck', 'Грузовик'),
    ]
    
    FUEL_TYPES = [
        ('petrol', 'Бензин'),
        ('diesel', 'Дизель'),
        ('electric', 'Электрический'),
        ('hybrid', 'Гибрид'),
    ]
    
    vin = models.CharField(max_length=17, unique=True, verbose_name="VIN номер")
    license_plate = models.CharField(max_length=15, verbose_name="гос. номер")
    brand = models.ForeignKey(Brand, on_delete=models.PROTECT, related_name='cars', verbose_name="бренд")
    model = models.CharField(max_length=100, verbose_name="модель")
    year = models.PositiveIntegerField(verbose_name="год выпуска")
    color = models.CharField(max_length=50, verbose_name="цвет")
    vehicle_type = models.CharField(
        max_length=20,
        choices=VEHICLE_TYPES,
        default='sedan',
        verbose_name="тип транспортного средства"
    )
    fuel_type = models.CharField(
        max_length=20,
        choices=FUEL_TYPES,
        default='petrol',
        verbose_name="тип топлива"
    )
    engine_volume = models.DecimalField(
        max_digits=3, 
        decimal_places=1,
        verbose_name="объем двигателя (л)"
    )
    power = models.PositiveIntegerField(verbose_name="мощность (л.с.)")
    transmission = models.CharField(
        max_length=20,
        choices=[
            ('manual', 'Механическая'),
            ('automatic', 'Автоматическая'),
            ('robot', 'Роботизированная'),
            ('variator', 'Вариатор')
        ],
        default='automatic',
        verbose_name="трансмиссия"
    )
    current_owner = models.CharField(max_length=200, verbose_name="текущий владелец")
    purchase_date = models.DateField(verbose_name="дата покупки")
    purchase_price = models.DecimalField(
        max_digits=12, 
        decimal_places=2,
        null=True, 
        blank=True,
        verbose_name="стоимость покупки"
    )
    current_mileage = models.PositiveIntegerField(verbose_name="текущий пробег (км)")
    mileage_update_date = models.DateField(verbose_name="дата обновления пробега")
    is_active = models.BooleanField(default=True, verbose_name="активный")
    in_service = models.BooleanField(default=False, verbose_name="в сервисе")
    description = models.TextField(blank=True, null=True, verbose_name="дополнительная информация")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="дата создания записи")
    updated_at = models.DateTimeField(auto_now=True, verbose_name="дата обновления")
    
    class Meta:
        verbose_name = "автомобиль"
        verbose_name_plural = "автомобили"
        ordering = ['brand', 'model', 'year']
        indexes = [
            models.Index(fields=['vin']),
            models.Index(fields=['license_plate']),
            models.Index(fields=['brand', 'model']),
        ]
    
    def __str__(self):
        return f"{self.brand.name} {self.model} ({self.year}) - {self.license_plate}"
    
    def age(self):
        from datetime import date
        return date.today().year - self.year


class MaintenanceRecord(models.Model):
    """Запись о техническом обслуживании автомобиля"""
    MAINTENANCE_TYPE_CHOICES = [
        ('regular', 'Регламентное ТО'),
        ('repair', 'Ремонт'),
        ('diagnostics', 'Диагностика'),
        ('tire_change', 'Замена шин'),
        ('other', 'Другое'),
    ]
    
    car = models.ForeignKey(Car, on_delete=models.CASCADE, related_name='maintenance_records', verbose_name="автомобиль")
    date = models.DateField(verbose_name="дата обслуживания")
    mileage_at_service = models.PositiveIntegerField(verbose_name="пробег на момент обслуживания")
    service_type = models.CharField(max_length=100, verbose_name="тип обслуживания")
    description = models.TextField(verbose_name="описание работ")
    cost = models.DecimalField(max_digits=10, decimal_places=2, verbose_name="стоимость")
    service_center = models.CharField(max_length=200, verbose_name="сервисный центр")
    maintenance_type = models.CharField(
        max_length=20,
        choices=MAINTENANCE_TYPE_CHOICES,
        default='regular',
        verbose_name="тип обслуживания"
    )
    technician = models.CharField(
        max_length=100,
        blank=True,
        null=True,
        verbose_name="механик"
    )
    warranty_work = models.BooleanField(
        default=False,
        verbose_name="гарантийная работа"
    )
    next_service_date = models.DateField(
        blank=True,
        null=True,
        verbose_name="дата следующего ТО"
    )
    next_service_mileage = models.PositiveIntegerField(
        blank=True,
        null=True,
        verbose_name="пробег следующего ТО"
    )
    invoice_number = models.CharField(
        max_length=50,
        blank=True,
        null=True,
        verbose_name="номер счета"
    )
    parts_cost = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        blank=True,
        null=True,
        verbose_name="стоимость запчастей"
    )
    labor_cost = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        blank=True,
        null=True,
        verbose_name="стоимость работ"
    )
    created_by = models.ForeignKey(
        CustomUser,
        on_delete=models.SET_NULL,
        null=True,
        related_name='maintenance_records',
        verbose_name="создал"
    )
    
    class Meta:
        verbose_name = "запись о ТО"
        verbose_name_plural = "записи о ТО"
        ordering = ['-date']
    
    def __str__(self):
        return f"{self.car} - {self.date} - {self.service_type}"